package rv4JaCa;

public interface IArtifact {
		public void informViolation(MsgSent m);
}
