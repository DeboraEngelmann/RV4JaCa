package rv4JaCa;

import jason.asSemantics.Message;

public interface IMonitor {
	public void propagateToMonitor(Message m);
}
